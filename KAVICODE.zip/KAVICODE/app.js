const express = require('express');
const bodyParser = require('body-parser');
const MongoClient = require('mongodb').MongoClient;
const app = express();
const port = 3000;

//  actual connection string
const mongoConnectionString = 'mongodb://localhost:27017/mydatabase';

//  actual database name
const dbName = 'mydatabase';

// Middleware to parse JSON data
app.use(bodyParser.json());

// Serve static files from 'public' directory (where your HTML, CSS, JS are)
app.use(express.static('kavicode'));

// Endpoint to handle form submission
app.post('/submit-form', (req, res) => {
    MongoClient.connect(mongoConnectionString, { useUnifiedTopology: true }, (err, client) => {
        if (err) {
            console.error(err);
            res.status(500).json({ error: 'Internal server error' });
            return;
        }
        const db = client.db(dbName);
        db.collection('registrations').insertOne(req.body, (err, result) => {
            if (err) {
                res.status(500).json({ error: 'Error inserting data' });
            } else {
                res.status(200).json({ message: 'Data inserted', _id: result.insertedId });
            }
            client.close();
        });
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
