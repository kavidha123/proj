document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('registrationForm');

    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submit action

        // FormData object to hold the form inputs
        const formData = new FormData(form);

        // Convert formData to an object
        const formObject = {};
        formData.forEach((value, key) => {
            formObject[key] = value;
        });

        // Send the form data as JSON to the server
        fetch('/submit-form', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formObject)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            console.log('Success:', data);
            // Handle success, such as displaying a success message or redirecting
        })
        .catch((error) => {
            console.error('Error:', error);
            // Handle errors, such as displaying an error message to the user
        });
    });
});
